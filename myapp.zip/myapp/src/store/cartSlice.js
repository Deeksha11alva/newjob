import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { DUMMY_PRODUCTS } from "../dummyproducts";
let initialState = {
  items: [],
  products: [],
  product: {},
};
const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    // getProducts(state, action) {
    //   console.log(action.payload, "avvcvvvv");
    //   return {
    //     ...state,
    //     products: [...action.payload],
    //   };
    // },
    searchProduct(state, action) {
      let updatedProducts;
      let newProducts = [...state.products];

      if (action.payload !== "") {
        updatedProducts = DUMMY_PRODUCTS.filter((prod) =>
          prod.title.toLowerCase().includes(action.payload.toLowerCase())
        );
      } else {
        updatedProducts = [...DUMMY_PRODUCTS];
      }

      return {
        ...state,
        products: updatedProducts,
      };
      //   if (action.payload !== "") {
      //   console.log(action.payload, "ppppppppp");
      //   let filteredItems = state.products.filter((prod) =>
      //     prod.title.toLowerCase().includes(action.payload.toLowerCase())
      //   );

      //   return {
      //     ...state,
      //     products: filteredItems,
      //   };
      //   } else {
      //     return {
      //       ...state,
      //       products: [...DUMMY_PRODUCTS],
      //     };
      //   }
    },
    addProduct(state, action) {
      let index = state.items.findIndex(
        (item) => item.id === action.payload.id
      );
      if (index >= 0) {
        state.items[index].quantity++;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }
    },
    removeProduct(state, action) {
      let index = state.items.findIndex((item) => item.id === action.payload);
      if (state.items[index].quantity !== 1) {
        state.items[index].quantity--;
      } else {
        state.items.splice(index, 1);
      }
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getProducts.fulfilled, (state, action) => {
      state.products = action.payload;
    });
    builder.addCase(getProduct.fulfilled, (state, action) => {
      state.product = action.payload;
    });
  },
});

export const { addProduct, removeProduct, searchProduct } = cartSlice.actions;
export default cartSlice.reducer;
export const getProducts = createAsyncThunk("products/get", async () => {
  const data = await fetch("https://dummyjson.com/products");

  const res = await data.json();
  console.log(res, "datttt");
  return res.products;
});
export const getProduct = createAsyncThunk("product/get", async (id) => {
  console.log("helll9");
  const data = await fetch(`https://dummyjson.com/products/${id}`);

  const res = await data.json();
  console.log(res, "123");
  return res;
});
