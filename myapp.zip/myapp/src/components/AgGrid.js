import React,{useState} from 'react';
import {AgGridReact} from 'ag-grid-react';
import Filter from './Filter';
import 'ag-grid-community/styles//ag-grid.css';
import 'ag-grid-community/styles//ag-theme-quartz.css';
const datarows= {
    columnDefs: [
        {headerName: "Make", field: "make", filter: true},
        {headerName: "Model", field: "model"},
        {headerName: "Price", field: "price"},
        { headerName: "Submission Date", field: "submissionDate" },


    ],
    rowData: [
        {make: "Toyota", model: "Celica", price: 35000, submissionDate: "2024-01-23T12:32:32+00:00"},
        {make: "Ford", model: "Mondeo", price: 32000, submissionDate :  "2021-04-23T12:32:32+00:00"},
        {make: "Porsche", model: "Boxster", price: 72000, submissionDate: "2020-07-23T12:32:32+00:00"}
    ]
}

export const AgGrid = () => {
    const [data,setData]=useState(datarows?.rowData);
    console.log(data,"dda")
  return (
    <div className="ag-theme-quartz"
    style={{
        height: '500px',
        width: '600px'
    }}>
        <Filter rowData={data} data={data} setData={setData} old={datarows?.rowData}/>
        hhhh<AgGridReact
        pagination={true}
        paginationPageSize={10}
        animateRows={true}
       
        enableCellChangeFlash={true}
              // domLayout="autoHeight"
              rowSelection="multiple"
              suppressRowClickSelection={true}
    columnDefs={datarows?.columnDefs}
    rowData={data}>
</AgGridReact></div>
  )
}
