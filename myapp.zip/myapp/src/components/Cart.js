import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";
const Cart = ({ cartItems, removeCart, addToCart }) => {
  const [show, setShow] = useState(false);
  const totalprice = cartItems.reduce(
    (acc, curr) => acc + curr.quantity * curr.price,
    0
  );
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button className="ml-auto" variant="primary" onClick={handleShow}>
        Cart
      </Button>

      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Total price:{totalprice}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {cartItems.map((cart) => (
            <>
              <p>
                {cart.title}
                <b>
                  {cart.quantity}*{cart.price}
                </b>

                <Button onClick={() => removeCart(cart.id)}>-</Button>
                <img src={cart.thumbnail} width="20%" height="20%" />
                <Button onClick={() => addToCart(cart)}>+</Button>
              </p>
            </>
          ))}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
export default Cart;
