import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { handleSort } from "./utils";
const SearchProducts = ({
  searchedProduct,
  setSearchedProduct,
  products,
  setProducts,
}) => {
  const handleChnage = (e) => {
    setSearchedProduct(e.target.value);
  };
  const handleSorting = (products, order) => {
    let res = handleSort(products, order, setProducts);
    console.log(res, "resss");

    setProducts(res);
  };
  let order;

  return (
    <div>
      <input value={searchedProduct} onChange={handleChnage} />
      <Button onClick={() => handleSorting(products, (order = "asc"))}>
        ASCENDING
      </Button>{" "}
      <Button onClick={() => handleSorting(products, (order = "dsc"))}>
        DESCENDING
      </Button>
    </div>
  );
};

export default SearchProducts;
