import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Button, ButtonGroup } from "react-bootstrap";
import axios from "axios";
import "./Product.css";
import { handleDelete } from "./utils";
import Col from "react-bootstrap/Col";
const Product = ({ prod, addToCart, removeCart }) => {
  const { id } = useParams();
  const downloadHandler = (img) => {
    axios({
      url: img,
      method: "GET",
      responseType: "blob", // important for handling binary data
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "image.png");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link); // cleanup
      })
      .catch((error) => {
        console.error("Error downloading file:", error);
      });
  };
  return (
    <>
      <Col xs={6} className="pink-border">
        <Link to={`/product/${prod.id}`}>
          <p>{prod.title}</p>

          <img src={prod.thumbnail} width="40%" height="40%" />
          <b>{prod.price}</b>
        </Link>
        <br />
        <Button
          variant="success"
          onClick={() => downloadHandler(prod.thumbnail)}
        >
          Download
        </Button>{" "}
        {/* <Button onClick={() => handleDelete(prod)}>Delete</Button>{" "} */}
        <Button onClick={() => addToCart(prod)}>ADD TO CART</Button>
        {"  "}
        <Button variant="warning" onClick={() => removeCart(prod.id)}>
          {" "}
          {"  "}
          REMOVE CART
        </Button>{" "}
      </Col>
    </>
  );
};

export default Product;
