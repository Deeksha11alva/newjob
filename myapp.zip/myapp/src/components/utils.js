export const handleSort = (items, order, setProducts) => {
  console.log("wewewe");
  const sorted = [...items].sort((a, b) => {
    const titleA = a.title.toLowerCase();
    const titleB = b.title.toLowerCase();
    if (order === "asc") {
      if (titleA < titleB) return -1;
      if (titleA > titleB) return 1;
    } else if (order === "dsc") {
      if (titleA > titleB) return -1;
      if (titleA < titleB) return 1;
    }

    return 0;
  });
  return sorted;
};
export const handleDelete = async (prod) => {
  let res = await fetch(`https://dummyjson.com/products/${prod.id}`, {
    method: "DELETE",
  });
  console.log(res.json());
};
