import React, { useState } from 'react'
import Tabs from "react-bootstrap/Tabs";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import DatePicker from "react-multi-date-picker";
import InputIcon from "react-multi-date-picker/components/input_icon";
import DatePanel from "react-multi-date-picker/plugins/date_panel";
import { Button } from 'react-bootstrap';
const Filter = (props) => {
    const [selectedDate, setSelectedDate] = useState();
    const [submisnStartDt, setSubmisnStartDt] = useState({});
    const [submisnEndDt, setSubmisnEndDt] = useState({});
    const [saveText, setSaveText] = useState("");
    const [saveFilter, setSaveFilter] = useState([])
    const [filter, setFilter] = useState({});
    const [selectop, setSelectop] = useState("")
    const [savebtntxt, setSavebtntext] = useState(false)
    const handleSubmissionMonthsChange = (arr) => {
        console.log(arr, "arrrr")
        setFilter({
            startMonth: arr[0]?.monthIndex,
            startYear: arr[0]?.year,
            startMonthNm: arr[0]?.month?.shortName,
            endMonth: arr[1]?.monthIndex,
            endYear: arr[1]?.year,
            endMonthNm: arr[1]?.month?.shortName,
        });
        setSelectedDate(arr);
        setSubmisnStartDt({
            submsnMnth: arr[0]?.monthIndex,
            submsnYear: arr[0]?.year,
            submnsMonthNm: arr[0]?.month?.shortName,
        });
        setSubmisnEndDt({
            submsnMnth: arr[1]?.monthIndex,
            submsnYear: arr[1]?.year,
            submnsMonthNm: arr[1]?.month?.shortName,
        });
    };
    const handleApplyFilter = () => {
        setSavebtntext(true)
        const selectedStartDate = new Date();
        const selectedEndDate = new Date();
        selectedStartDate.setMonth(submisnStartDt?.submsnMnth);
        selectedStartDate.setFullYear(submisnStartDt?.submsnYear);
        selectedEndDate.setMonth(submisnEndDt?.submsnMnth);
        selectedEndDate.setFullYear(submisnEndDt?.submsnYear);
        console.log(selectedStartDate, selectedEndDate, "endddddddd")
        const filteredGridData = props.rowData.filter((item) => {
            const year = new Date(item.submissionDate).getFullYear();
            const month = new Date(item.submissionDate).getMonth();
            const submittedDate = new Date();

            submittedDate.setMonth(month);
            submittedDate.setFullYear(year);
            submittedDate.setMinutes(0);
            submittedDate.setSeconds(0);

            const lastDayofCurrentMonth = new Date(
                new Date().getFullYear(),
                new Date().getMonth() + 1,
                0
            ).getDate();

            const selectedStartDt = new Date(selectedDate[0]);
            const selectedEndDt = new Date(selectedDate[1]);
            selectedEndDt.setDate(lastDayofCurrentMonth);
            console.log(submittedDate, selectedStartDate, selectedEndDate, "filteredddddddddddd")
            return (
                submittedDate >= selectedStartDate &&
                submittedDate <= selectedEndDate)
        })
        console.log(filteredGridData, "filteredddddddddddd")
        props.setData(filteredGridData)
    }
    const handleSelect = (e) => {
        console.log(e.target.value, "eeeeeeeeeeeeeeee");
        setSelectop(e.target.value);
    }
    const handleSave = () => {
        props.setData(props.old)
        const filterCriPayload = {};
        let partnerPayload = [];
        const defaultSubmission = []
        filterCriPayload.startMonth = filter.startMonth;
        filterCriPayload.endMonth = filter.endMonth;
        filterCriPayload.startYear = filter.startYear;
        filterCriPayload.endYear = filter.endYear;
        filterCriPayload.startMonthNm = filter.startMonthNm;
        filterCriPayload.endMonthNm = filter.endMonthNm;
        const payload = {

            Filters: [
                {
                    FilterName: saveText,
                    FilterCriteria: JSON.stringify(filterCriPayload),
                    AttributeName: "Submission Period",
                },
            ]
        }
        setFilter(payload)
        console.log(payload, "fffffffffff")
    }
    const handleChange = (e) => {
        setSaveText(e.target.value);


    }
    const handleApplySavedFilter = () => {
        console.log(filter, selectop, "filyter:::::")
        let newFilter = filter?.Filters.map((fil) => {
            if (fil.FilterName === "deeksha") {
                return fil
            }
        })
        console.log(newFilter, "oooooooooooooooooo")
        const criteria = JSON.parse(newFilter[0].FilterCriteria);
        const savedStartDt = new Date();
        const savedEndDt = new Date();
        const lastDayofCurrentMonth = new Date(
            new Date().getFullYear(),
            new Date().getMonth() + 1,
            0
        ).getDate();

        savedStartDt.setFullYear(criteria.startYear);
        savedStartDt.setMonth(criteria.startMonth);
        savedStartDt.setDate(1);

        savedEndDt.setFullYear(criteria.endYear);
        savedEndDt.setMonth(criteria.endMonth);
        savedEndDt.setDate(lastDayofCurrentMonth);

        const filteredGridData = props.rowData.filter((item) => {
            const year = new Date(item.submissionDate).getFullYear();
            const month = new Date(item.submissionDate).getMonth();
            const submittedDate = new Date();

            submittedDate.setMonth(month);
            submittedDate.setFullYear(year);
            submittedDate.setMinutes(0);
            submittedDate.setSeconds(0);

            const lastDayofCurrentMonth = new Date(
                new Date().getFullYear(),
                new Date().getMonth() + 1,
                0
            ).getDate();

            const selectedStartDt = new Date(selectedDate[0]);
            const selectedEndDt = new Date(selectedDate[1]);
            selectedEndDt.setDate(lastDayofCurrentMonth);
            // console.log(submittedDate, selectedStartDate, selectedEndDate, "filteredddddddddddd")
            return (
                submittedDate >= savedStartDt &&
                submittedDate <= savedEndDt)
        })
        console.log(filteredGridData, "filteredddddddddddd")
        props.setData(filteredGridData)
    }


    return (
        <div> <Row className="d-flex">
            <Col

                className="d-flex justify-content-start filter-wrapper datePickerContainer"
            >
                <DatePicker
                    className="custom-input"
                    portal
                    onlyMonthPicker
                    range
                    calendarPosition="right"
                    plugins={[<DatePanel header="Selected Range" />]}
                    render={<InputIcon style={{ height: "36px" }} />}
                    // minDate={
                    //     new Date(previousYear, date.month.number - 1, 1, 0, 0, 0, 0)
                    // }
                    maxDate={new Date()}
                    // months={date.months.map((month) => month.shortName)}
                    value={selectedDate}
                    onChange={handleSubmissionMonthsChange}
                />
            </Col>
            <Col>
                <Button onClick={() => handleApplyFilter()}>Apply</Button>
                <Button onClick={() => handleSave()}>Save</Button>
                <Button onClick={() => handleApplySavedFilter()}>Apply saved filter</Button>
            </Col>
        </Row>
            {savebtntxt && <input type="text" defaultValue={saveText} onChange={handleChange} />}
            <select value={selectop} onChange={handleSelect}>
                <option disabled>Select</option>
                {filter?.Filters?.map((f) => (
                    <option key={f?.FilterName} value={f?.FilterName}>
                        {f?.FilterName}
                    </option>
                ))}
            </select>


        </div>
    )
}

export default Filter