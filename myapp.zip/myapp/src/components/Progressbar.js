import { useEffect, useState } from "react";
import { MAX, MIN } from "../constants";
import "./Product.css";
export default function ProgressBar({ value = 0, onComplete = () => {} }) {
  const [percent, setPercent] = useState(value);

  useEffect(() => {
    setPercent(Math.min(Math.max(value, MIN), MAX));

    if (value >= MAX) {
      onComplete();
    }
  }, [value]);
  console.log(value, "vallllll", MAX, MIN, percent / MAX);
  return (
    <div className="progress">
      <span
        style={{
          color: percent > 49 ? "white" : "black",
          //   background: percent > 49 ? "green" : "red",
        }}
      >
        {percent.toFixed()}%
      </span>
      <div
        // style={{ width: `${percent}%` }}
        style={{
          transform: `scaleX(${percent / MAX})`,
          transformOrigin: "left",
        }}
        aria-valuemin={MIN}
        aria-valuemax={MAX}
        aria-valuenow={percent}
        role="progressbar"
      />
    </div>
  );
}
