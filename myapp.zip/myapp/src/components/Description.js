import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getProduct } from "../store/cartSlice";
import { useDispatch, useSelector } from "react-redux";
const Description = () => {
  const { id } = useParams();
  const data = useSelector((state) => state.cart.product);
  const dispatch = useDispatch();
  const [products, setProducts] = useState([]);
  useEffect(() => {
    if (id) {
      console.log("reduuuuuuuuuux", id);
      dispatch(getProduct(id));
      // const fn = async () => {
      //   let res = await fetch(`https://dummyjson.com/products/${id}`);

      //   let result = await res.json();

      //   setProducts(result);
      // };
      // fn();
    }
  }, [id]);
  console.log(data, "DATTTTTTTTTTTTTTTTT");
  return <div>{data.title}</div>;
};

export default Description;
