import React, { useState } from "react";
import { InputGroup, Form, Button } from "react-bootstrap";
const CreateProduct = ({ setProducts }) => {
  const [newProduct, setNewProduct] = useState({ title: "", price: "" });
  const handleChange = (e) => {
    setNewProduct({
      [e.target.name]: e.target.value,
    });
  };
  const handleCreate = async () => {
    let res = await fetch("https://dummyjson.com/products/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: 10000,
        title: "iPhone X13333",
        description:
          "SIM-Free, Model A19211 6.5-inch Super Retina HD display with OLED technology A12 Bionic chip with ...",
        price: 899,
        discountPercentage: 17.94,
        rating: 4.44,
        stock: 34,
        brand: "Apple",
        category: "smartphones",
        thumbnail: "https://i.dummyjson.com/data/products/2/thumbnail.jpg",
        images: [
          "https://i.dummyjson.com/data/products/2/1.jpg",
          "https://i.dummyjson.com/data/products/2/2.jpg",
          "https://i.dummyjson.com/data/products/2/3.jpg",
          "https://i.dummyjson.com/data/products/2/thumbnail.jpg",
        ],
      }),
    });
    let result = await res.json();
    setProducts((prev) => [...prev, { ...result }]);
    console.log(result, "resss");
  };
  return (
    <div>
      <InputGroup size="sm" className="mb-3">
        <InputGroup.Text id="inputGroup-sizing-sm">Small</InputGroup.Text>
        <Form.Control
          onChange={(e) => handleChange(e)}
          aria-label="Small"
          aria-describedby="inputGroup-sizing-sm"
        />
        <InputGroup.Text id="inputGroup-sizing-sm">Small</InputGroup.Text>
        <br />
        <Form.Control
          onChange={(e) => handleChange(e)}
          aria-label="Small"
          aria-describedby="inputGroup-sizing-sm"
        />
        <InputGroup.Text id="inputGroup-sizing-sm">Small</InputGroup.Text>{" "}
        <br />
        <Form.Control
          onChange={(e) => handleChange(e)}
          aria-label="Small"
          aria-describedby="inputGroup-sizing-sm"
        />
      </InputGroup>
      <Button onClick={handleCreate}>Create product</Button>
    </div>
  );
};

export default CreateProduct;
