import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { handleSort } from "../utils";
import { useDispatch } from "react-redux";
import { getProducts } from "../../store/cartSlice";
const SearchProductsredux = ({
  searchedProduct,
  setSearchedProduct,
  products,
  setProducts,
  handleSearch,
}) => {
  const dispatch = useDispatch();
  const handleChnage = (e) => {
    setSearchedProduct(e.target.value);
    handleSearch();
  };
  const handleSorting = (products, order) => {
    let res = handleSort(products, order, setProducts);
    console.log(res, "resss");
    dispatch(getProducts(res));
  };
  let order;
  console.log(searchedProduct, "sssss");
  return (
    <div>
      <input value={searchedProduct} onChange={handleChnage} />
      <Button onClick={() => handleSorting(products, (order = "asc"))}>
        ASCENDING
      </Button>{" "}
      <Button onClick={() => handleSorting(products, (order = "dsc"))}>
        DESCENDING
      </Button>
    </div>
  );
};

export default SearchProductsredux;
