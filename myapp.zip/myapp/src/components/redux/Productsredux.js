import React, { useEffect, useState } from "react";
import Productredux from "./Productredux";
import { Container } from "react-bootstrap";
import { DUMMY_PRODUCTS } from "../../dummyproducts";
import "../Product.css";
import { useDispatch, useSelector } from "react-redux";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";

import {
  addProduct,
  getProducts,
  removeProduct,
  searchProduct,
} from "../../store/cartSlice";
import Cartredux from "./Cartredux";
import SearchProductsredux from "./Searchproductsredux";
import { useTheme } from "../../theme-context";
let productsPerPage = 4;
const Productsredux = () => {
  let productsCount = useSelector((state) => state.cart.products);
  let productsLength = [...productsCount];
  console.log(productsCount, productsLength, "pppproductsciount");
  const dispatch = useDispatch();
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [searchedProduct, setSearchedProduct] = useState("");
  const [order, setOrder] = useState("asc");
  const [currentPage, setCurrentpage] = useState(1);

  useEffect(() => {
    dispatch(getProducts());
  }, []);

  const handleAddCart = (prod) => {
    dispatch(addProduct(prod));
  };
  const handleRemoveCart = (id) => {
    dispatch(removeProduct(id));
  };
  useEffect(() => {
    if (searchedProduct === "") {
      dispatch(getProducts());
    } else {
      dispatch(searchProduct(searchedProduct));
    }
  }, [searchedProduct]);
  const handleSearch = () => {
    const newTotalPages = Math.ceil(productsCount.length / productsPerPage);
    setCurrentpage(currentPage > newTotalPages ? newTotalPages : currentPage);
  };
  // useEffect(() => {
  // // Update displayProducts when productsCount changes
  // const lastIndex = currentPage * productsPerPage;
  // const firstIndex = lastIndex - productsPerPage;
  // setDisplayProducts(productsCount.slice(firstIndex, lastIndex));

  // // Calculate total pages again after the search
  // const newTotalPages = Math.ceil(productsCount.length / productsPerPage);

  // // Set current page based on the new total pages
  // if (currentPage > newTotalPages) {
  //   setCurrentpage(newTotalPages);
  // }
  // }, [currentPage, productsCount]);
  const lastIndex = currentPage * productsPerPage;
  const firstIndex = lastIndex - productsPerPage;
  let displayProducts = productsCount.slice(firstIndex, lastIndex);
  const totalpages = Math.ceil(productsLength.length / productsPerPage);

  const handlePageChange = (e, index) => {
    console.log(index, "oooooooooo");
    setCurrentpage(index);
    if (searchedProduct === "") {
      dispatch(getProducts());
    } else {
      dispatch(searchProduct(searchedProduct));
    }
  };

  console.log(displayProducts, searchedProduct, "cccccccc");
  return (
    <>
      <Tabs
        defaultActiveKey="home"
        id="justify-tab-example"
        className="mb-3"
        justify
      >
        <Tab eventKey="home" title="Home">
          <Cartredux
            handleAddCart={handleAddCart}
            handleRemoveCart={handleRemoveCart}
            setCartItems={setCartItems}
          />
          <SearchProductsredux
            products={productsLength}
            setProducts={setProducts}
            searchedProduct={searchedProduct}
            setSearchedProduct={setSearchedProduct}
            handleSearch={handleSearch}
          />
          {/* <CreateProduct setProducts={setProducts} /> */}
          <div>
            <Container>
              <Row>
                {displayProducts.map((prod) => {
                  return (
                    <Productredux
                      prod={prod}
                      handleRemoveCart={handleRemoveCart}
                      handleAddCart={handleAddCart}
                      //   addToCart={addToCart}
                      //   removeCart={removeCart}
                    />
                  );
                })}
              </Row>
            </Container>
          </div>
          <div className="pagination">
            {Array.from({ length: totalpages }).map((_, index) => {
              return (
                <button onClick={(e) => handlePageChange(e, index + 1)}>
                  {index + 1}
                </button>
              );
            })}
          </div>
        </Tab>
        <Tab eventKey="profile" title="Profile">
          Tab content for Profile
        </Tab>
        <Tab eventKey="longer-tab" title="Loooonger Tab">
          Tab content for Loooonger Tab
        </Tab>
        <Tab eventKey="contact" title="Contact">
          Tab content for Contact
        </Tab>
      </Tabs>
      <Tab.Container id="left-tabs-example" defaultActiveKey="first">
        <Row>
          <Col sm={3}>
            <Nav variant="pills" className="flex-column">
              <Nav.Item>
                <Nav.Link eventKey="first">Tab 1</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="second">Tab 2</Nav.Link>
              </Nav.Item>
            </Nav>
          </Col>
          <Col sm={9}>
            <Tab.Content>
              <Tab.Pane eventKey="first">First tab content</Tab.Pane>
              <Tab.Pane eventKey="second">Second tab content</Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </>
  );
};

export default Productsredux;
