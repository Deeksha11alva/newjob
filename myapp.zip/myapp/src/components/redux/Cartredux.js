import React, { useEffect, useState } from "react";
import { Modal, Button, Table } from "react-bootstrap";
import { useSelector } from "react-redux";
const Cartredux = ({ handleRemoveCart, handleAddCart, setCartItems }) => {
  const cartItems = useSelector((state) => state.cart.items);
  console.log(cartItems, "cartttt");
  const [show, setShow] = useState(false);
  const [cartProducts, setCartProducts] = useState([]);

  const [saveProducts, setSaveProducts] = useState([]);
  const totalprice = cartItems.reduce(
    (acc, curr) => acc + curr.quantity * curr.price,
    0
  );
  let copyproductsnew = JSON.parse(localStorage.getItem("items"));
  useEffect(() => {
    if (copyproductsnew) {
      const updatedCopyProducts = cartItems.map((prod) => {
        const matchingCartItem = copyproductsnew.find(
          (cart) => cart.id === prod.id
        );
        if (matchingCartItem) {
          // If the item exists in both arrays, update 'checked' attribute
          return { ...prod, checked: matchingCartItem.checked };
        }
        return prod; // If the item doesn't exist in 'cartItems', keep it as it is
      });
      console.log(updatedCopyProducts, copyproductsnew, "htttpp");
      setCartProducts(updatedCopyProducts);
    } else {
      setCartProducts(cartItems);
    }
  }, [cartItems]);
  const handleClose = () => {
    let items = cartProducts.map((cartProduct) => {
      const existingProductInSaveProducts = saveProducts
        .slice()
        .reverse()
        .find((existingProduct) => existingProduct.id === cartProduct.id);
console.log(!existingProductInSaveProducts?.checked ,existingProductInSaveProducts, !cartProduct.checked,"ooooooiiiiippppp")
      return {
        ...cartProduct,
        checked:
          !existingProductInSaveProducts?.checked ?? !cartProduct.checked,
      };
    });

    localStorage.setItem("items", JSON.stringify(items));
    setSaveProducts([]);
    setCartProducts(items);
    setShow(false);
    // let sameProducts = [];
    // console.log(saveProducts, "savvvvvvvvvvvvv::::::::::::");
    // saveProducts.forEach((saveProduct) => {
    //   const existingIndex = sameProducts.findIndex(
    //     (existingProduct) => existingProduct.id === saveProduct.id
    //   );

    //   if (existingIndex !== -1) {
    //     // If the product already exists, update it with the latest information
    //     sameProducts[existingIndex] = {
    //       ...saveProduct,
    //       checked: !sameProducts[existingIndex].checked,
    //     };
    //   } else {
    //     // If the product does not exist, add it to the array
    //     sameProducts.push({ ...saveProduct, checked: !saveProduct.checked });
    //   }
    // });
    // localStorage.setItem("items", JSON.stringify(sameProducts));
    // // setSaveProducts(sameProducts);
    // console.log(sameProducts, "///////////////////////////");
    // setCartProducts(sameProducts);
    // setShow(false);
  };
  const handleShow = () => {
    // console.log(cartProducts, "shooooooooooooo");
    // if (copyproductsnew) {
    //   const updatedCopyProducts = cartProducts.map((prod) => {
    //     const matchingCartItem = copyproductsnew.find(
    //       (cart) => cart.id === prod.id
    //     );
    //     if (matchingCartItem) {
    //       // If the item exists in both arrays, update 'checked' attribute
    //       return { ...prod, checked: matchingCartItem.checked };
    //     }
    //     return prod; // If the item doesn't exist in 'cartItems', keep it as it is
    //   });
    //   console.log(updatedCopyProducts, copyproductsnew, "htttpp");
    //   setCartProducts(updatedCopyProducts);
    // } else {
    //   setCartProducts(cartItems);
    // }
    setShow(true);
  };
  const handleChange = (e, item) => {
    setSaveProducts((prev) => [
      ...prev,
      { ...item, checked: e.target.checked },
    ]);
    // let cartIndex = cartProducts?.findIndex((cart) => cart.id === item.id);
    // console.log(cartIndex, e.target.checked, "carrtttyt");
    // setCartProducts((prevCartItems) => {
    //   const updatedCartItems = [...prevCartItems];
    //   updatedCartItems[cartIndex] = {
    //     ...updatedCartItems[cartIndex],
    //     checked: e.target.checked,
    //   };
    //   return updatedCartItems;
    // });
  };
  const handleCloseModal = () => {};
  const handleSave = () => {
    console.log(cartProducts, saveProducts, "cart*******777");
    let items = cartProducts.map((cartProduct) => {
      const existingProductInSaveProducts = saveProducts
        // .slice()
        // .reverse()
        .find((existingProduct) => existingProduct.id === cartProduct.id);
console.log( existingProductInSaveProducts?.checked ,existingProductInSaveProducts,cartProduct.checked,"notttttttttttt")
      return {
        ...cartProduct,
        checked: existingProductInSaveProducts?.checked ?? cartProduct.checked,
      };
    });
    console.log(items, "oiiiiiiiiiiiiiii");
    localStorage.setItem("items", JSON.stringify(items));
    setSaveProducts([]);
    setCartProducts(items);
    setShow(false);
  };

  console.log(cartProducts, "1234455");
  return (
    <>
      <Button className="ml-auto" variant="primary" onClick={handleShow}>
        Cart
      </Button>

      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Total price:{totalprice}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Table>
            <tbody>
              {cartProducts.map((cart) => (
                <tr>
                  <td>{cart.title}</td>
                  <td>
                    {cart.quantity}*{cart.price}
                  </td>

                  <td>
                    {" "}
                    <Button onClick={() => handleRemoveCart(cart.id)}>-</Button>
                  </td>
                  <td>
                    {" "}
                    <img src={cart.thumbnail} width="20%" height="20%" />{" "}
                  </td>
                  <td>
                    {" "}
                    <Button onClick={() => handleAddCart(cart)}>+</Button>{" "}
                  </td>
                  <td>
                    {" "}
                    <input
                      type="checkbox"
                      style={{ width: "39px", height: "29px" }}
                      defaultChecked={cart?.checked}
                      onChange={(e) => handleChange(e, cart)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
export default Cartredux;
