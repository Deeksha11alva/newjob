import React, { useEffect, useState } from "react";
import Product from "./Product";
import Cart from "./Cart";
import SearchProducts from "./SearchProducts";
import { handleSort } from "./utils";
import { Button } from "react-bootstrap";
import CreateProduct from "./CreateProduct";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import "./Product.css";
import { useTheme } from "../theme-context";
import ProgressBar from "./Progressbar";
let productsPerPage = 4;

const Products = () => {
  const { theme, toggleTheme } = useTheme();
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [searchedProduct, setSearchedProduct] = useState("");
  const [order, setOrder] = useState("asc");
  const [currentPage, setCurrentpage] = useState(1);
  const [value, setValue] = useState(0);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setInterval(() => {
      setValue((val) => val + 0.1);
    }, 20);
  }, []);

  console.log(theme, "ccccccccccccccccccccc");
  useEffect(() => {
    const fn = async () => {
      let res = await fetch("https://dummyjson.com/products");

      let result = await res.json();

      let response = handleSort(result.products, order);
      setProducts(response);
    };
    fn();
  }, []);
  const lastIndex = currentPage * productsPerPage;
  const firstIndex = lastIndex - productsPerPage;
  const productsCount = products && products.slice(firstIndex, lastIndex);
  const totalpages = Math.ceil(products.length / productsPerPage);
  useEffect(() => {
    const fn = async () => {
      let res = await fetch(
        `https://dummyjson.com/products/search?q=${searchedProduct}`
      );

      let result = await res.json();

      let response = handleSort(result.products, order);
      setProducts(response);
    };
    fn();
  }, [searchedProduct]);
  const addToCart = (prod) => {
    const findIndex = cartItems.findIndex((prods) => prods.id === prod.id);
    console.log(findIndex, "ppppppppp");
    if (findIndex >= 0) {
      const updatedItems = [...cartItems];

      updatedItems[findIndex].quantity = updatedItems[findIndex].quantity + 1;
      setCartItems(updatedItems);
    } else {
      setCartItems([...cartItems, { ...prod, quantity: Number(1) }]);
    }
  };
  const removeCart = (id) => {
    const findIndex = cartItems.findIndex((prods) => prods.id === id);
    const updatedItems = [...cartItems];
    const qty = updatedItems[findIndex].quantity;

    if (qty === 1) {
      updatedItems.splice(findIndex, 1);

      setCartItems(updatedItems);
    } else {
      updatedItems[findIndex].quantity = updatedItems[findIndex].quantity - 1;
      setCartItems(updatedItems);
      //   setCartItems([...cartItems, { ...prod, quantity: Number(1) }]);
    }
  };
  const handlePageChange = (e, index) => {
    console.log(index, "oooooooooo");
    setCurrentpage(index);
  };
  const handleToggle = () => {
    toggleTheme();
  };

  return (
    <div className={`page ${theme}`}>
      <div className="app">
        <span>Progress Bar</span>
        {/* <ProgressBar value={value} onComplete={() => setSuccess(true)} /> */}
        <span>{success ? "Complete!" : "Loading..."}</span>
      </div>
      <Cart
        addToCart={addToCart}
        removeCart={removeCart}
        cartItems={cartItems}
      />
      <div className="mode-switch">
        <label>
          <input
            type="checkbox"
            checked={theme === "dark"}
            onChange={handleToggle}
          />
          <span className="slider round"></span>
        </label>
      </div>
      <SearchProducts
        products={products}
        setProducts={setProducts}
        searchedProduct={searchedProduct}
        setSearchedProduct={setSearchedProduct}
      />
      <CreateProduct setProducts={setProducts} />
      <div>
        <Container>
          <Row>
            {productsCount.map((prod) => {
              return (
                <Product
                  prod={prod}
                  addToCart={addToCart}
                  removeCart={removeCart}
                />
              );
            })}
          </Row>
        </Container>
      </div>
      <div className="pagination">
        {Array.from({ length: totalpages }).map((_, index) => {
          return (
            <button onClick={(e) => handlePageChange(e, index + 1)}>
              {index + 1}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Products;
