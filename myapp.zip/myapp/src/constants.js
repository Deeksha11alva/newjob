export const MIN = 0;
export const MAX = 100;
