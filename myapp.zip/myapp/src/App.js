import logo from "./logo.svg";
import "./App.css";
import { Routes, Route, Outlet, Link } from "react-router-dom";
import Products from "./components/Products";
import Home from "./components/Home";
import Product from "./components/Product";
import Description from "./components/Description";
import Productsredux from "./components/redux/Productsredux";
import { ThemeProvider } from "./theme-context";
import PhoneOtpForm from "./components/PhoneOtpForn";
import "./index.css";
import LanguageSelector from "./components/languageSelector";
import { Trans, useTranslation } from "react-i18next";
import { AgGrid } from "./components/AgGrid";
function App() {
  const { t } = useTranslation();
  const { line1, line2 } = t("description");

  return (
    <ThemeProvider>
      <LanguageSelector />
      <h1>{t("greeting")}</h1>
      <span>
        <Trans
          // i18nKey={"description.line1"}
          i18nKey={line1}
          values={{
            channel: "RoadsideCoder",
          }}
          components={{ 1: <b /> }}
        ></Trans>
      </span>
      <span>{line2}</span>
      <PhoneOtpForm />
      <Routes>
        {/* <Route path="/" element={<Layout />}/> */}

        <Route index element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/product/:id" element={<Description />} />
        <Route path="/aggrid" element={<AgGrid />} />
        <Route path="/product/redux" element={<Productsredux />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;
