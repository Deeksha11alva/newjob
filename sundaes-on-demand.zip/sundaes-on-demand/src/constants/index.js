export const pricePerItem = {
  scoops: 2,
  toppings: 1.5,
};
